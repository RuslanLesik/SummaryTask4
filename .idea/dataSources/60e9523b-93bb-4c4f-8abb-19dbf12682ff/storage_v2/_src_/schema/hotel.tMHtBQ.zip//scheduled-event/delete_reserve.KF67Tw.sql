create definer = root@localhost event delete_reserve
  on schedule
    every '1' MINUTE
      starts '2020-04-24 17:26:12'
  enable
do
  DELETE FROM reserves
WHERE date_add(date_create, interval 2 day) = curdate()
and status_reserve = false;

